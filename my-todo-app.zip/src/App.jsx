import React, { useState, useEffect } from "react";
import axios from "axios";

const App = () => {
  const [users, setUsers] = useState([]);
  const [todos, setTodos] = useState([]);
  const [filteredTodos, setFilteredTodos] = useState([]);
  const [selectedUser, setSelectedUser] = useState("");
  const [priority, setPriority] = useState("All");
  const [newTodo, setNewTodo] = useState({
    title: "",
    description: "",
    priority: "Low",
    userId: "",
  });

  useEffect(() => {
    fetch("http://localhost:5000/api/users")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to fetch users");
        }
        return response.json();
      })
      .then((data) => {
        console.log("Fetched Users:", data); // Debugging
        setUsers(Array.isArray(data) ? data : []); // Ensure it's an array
      })
      .catch((error) => {
        console.error("Error fetching users:", error);
        setUsers([]); // Prevent map() errors
      });
  }, []);

  useEffect(() => {
    fetch("http://localhost:5000/api/todos")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to fetch todos");
        }
        return response.json();
      })
      .then((data) => {
        console.log("Fetched Todos:", data); // Debugging
        setTodos(Array.isArray(data.todos) ? data.todos : []); // Set correct array
      })
      .catch((error) => {
        console.error("Error fetching todos:", error);
        setTodos([]); // Prevent map() errors
      });
  }, []);

  const fetchUsers = async () => {
    try {
      const res = await axios.get("http://localhost:5000/users");
      setUsers(res.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const fetchTodos = async () => {
    try {
      const res = await axios.get("http://localhost:5000/todos");

      console.log("askjdcnskvjns", res);
      setTodos(res.data);
      setFilteredTodos(res.data);
    } catch (error) {
      console.error("Error fetching todos:", error);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch Users
        const usersRes = await axios.get("http://localhost:5000/users");
        setUsers(usersRes.data);

        // Fetch Todos
        const todosRes = await axios.get("http://localhost:5000/todos");
        console.log("Fetched Todos:", todosRes.data);
        setTodos(todosRes.data);
        setFilteredTodos(todosRes.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const handleInputChange = (e) => {
    setNewTodo({
      ...newTodo,
      [e.target.name]: e.target.value,
    });
  };

  const handleAddTodo = () => {
    fetch("http://localhost:5000/api/todos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newTodo),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          setTodos([...todos, data.todo]); // Append new todo
          setNewTodo({
            title: "",
            description: "",
            priority: "Low",
            assignedTo: "",
          }); // Reset form
        } else {
          console.error("Failed to add todo:", data.message);
        }
      })
      .catch((error) => console.error("Error adding todo:", error));
  };

  const filterTodos = () => {
    let filtered = [...todos];

    // Filter by selected user
    if (selectedUser && selectedUser !== "All Users") {
      filtered = filtered.filter((todo) => todo.userId === selectedUser);
    }

    // Filter by priority
    if (priority && priority !== "All") {
      filtered = filtered.filter(
        (todo) => todo.priority.toLowerCase() === priority.toLowerCase()
      );
    }

    setFilteredTodos(filtered);
  };

  return (
    <div style={styles.container}>
      <h2>Todo Management</h2>

      {/* User Dropdown */}
      {/* <label>Select a User: </label>
      <select
        value={selectedUser}
        onChange={(e) => setSelectedUser(e.target.value)}
        style={styles.input}
      >
        <option value="">All Users</option>
        {users.map((user) => (
          <option key={user._id} value={user._id}>
            {user.username}
          </option>
        ))}
      </select> */}

      {/* Todo Form */}
      <h3>Create a New Todo</h3>
      <input
        type="text"
        placeholder="Title"
        value={newTodo.title}
        onChange={handleInputChange}
        style={styles.input}
      />
      <input
        type="text"
        placeholder="Description"
        value={newTodo.description}
        onChange={handleInputChange}
        style={styles.input}
      />
      <select
        value={newTodo.priority}
        onChange={(e) => setNewTodo({ ...newTodo, priority: e.target.value })}
        style={styles.input}
      >
        <option value="Low">Low</option>
        <option value="Medium">Medium</option>
        <option value="High">High</option>
      </select>
      <select
        value={newTodo.userId}
        onChange={(e) => setNewTodo({ ...newTodo, userId: e.target.value })}
        style={styles.input}
      >
        <option value="">Select User</option>
        {users.map((user) => (
          <option key={user._id} value={user._id}>
            {user.username}
          </option>
        ))}
      </select>
      <button onClick={handleAddTodo} style={styles.addButton}>
        Add Todo
      </button>

      {/* Filter Section */}
      <h3>Filter Todos</h3>
      <select
        value={priority}
        onChange={(e) => setPriority(e.target.value)}
        style={styles.input}
      >
        <option value="All">All Priorities</option>
        <option value="Low">Low</option>
        <option value="Medium">Medium</option>
        <option value="High">High</option>
      </select>
      <button onClick={filterTodos} style={styles.filterButton}>
        Search
      </button>

      {/* Todo Lists */}
      <div style={styles.todoContainer}>
        <div>
          <h3>All Todos</h3>
          <table border="1">
            <thead>
              <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Priority</th>
                <th>User</th>
              </tr>
            </thead>
            <tbody>
              {todos.map((todo) => (
                <tr key={todo._id}>
                  <td>{todo.title}</td>
                  <td>{todo.description}</td>
                  <td>{todo.priority}</td>
                  <td>
                    {todo.assignedTo?.username || "Unknown"}{" "}
                    {/* Ensure correct reference */}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div>
          <h3>Filtered Todos</h3>
          <table border="1">
            <thead>
              <tr>
                <th>Title</th>
                <th>Priority</th>
              </tr>
            </thead>
            <tbody>
              {filteredTodos.map((todo) => (
                <tr key={todo._id}>
                  <td>{todo.title}</td>
                  <td>{todo.priority}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Inline CSS styles
const styles = {
  container: {
    width: "80%",
    margin: "auto",
    textAlign: "center",
    fontFamily: "Arial, sans-serif",
  },
  input: {
    margin: "5px",
    padding: "10px",
    fontSize: "16px",
    width: "200px",
  },
  addButton: {
    padding: "10px",
    backgroundColor: "green",
    color: "white",
    border: "none",
    cursor: "pointer",
  },
  filterButton: {
    padding: "10px",
    backgroundColor: "blue",
    color: "white",
    border: "none",
    cursor: "pointer",
  },
  todoContainer: {
    display: "flex",
    justifyContent: "space-around",
    marginTop: "20px",
  },
};

export default App;
