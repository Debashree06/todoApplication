module.exports = {
  plugins: {
    "@tailwindcss/postcss": {},
    tailwindcss: {},
    autoprefixer: {},
  },
};
