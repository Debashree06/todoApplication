const Todo = require("../models/Todo");

// Create a new todo
exports.createTodo = async (req, res) => {
  try {
    const { title, description, tags, priority, assignedUsers, notes } =
      req.body;
    const newTodo = new Todo({
      title,
      description,
      tags,
      priority,
      assignedUsers,
      notes,
    });
    await newTodo.save();
    res.status(201).json(newTodo);
  } catch (error) {
    res.status(500).json({ error: "Server Error: " + error.message });
  }
};

// Get all todos
exports.getTodos = async (req, res) => {
  try {
    const todos = await Todo.find().populate("assignedTo").exec(); // Populating User
    res.status(200).json(todos);
  } catch (error) {
    res
      .status(500)
      .json({ error: "Error fetching todos", details: error.message });
  }
};

// Update a todo
exports.updateTodo = async (req, res) => {
  try {
    const updatedTodo = await Todo.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!updatedTodo) return res.status(404).json({ error: "Todo not found" });
    res.status(200).json(updatedTodo);
  } catch (error) {
    res.status(500).json({ error: "Server Error: " + error.message });
  }
};

// Delete a todo
exports.deleteTodo = async (req, res) => {
  try {
    const deletedTodo = await Todo.findByIdAndDelete(req.params.id);
    if (!deletedTodo) return res.status(404).json({ error: "Todo not found" });
    res.status(200).json({ message: "Todo deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Server Error: " + error.message });
  }
};

mmodule.exports = { getTodos, createTodo, updateTodo, deleteTodo };
