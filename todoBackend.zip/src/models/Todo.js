const mongoose = require("mongoose");

const todoSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String },
  priority: { type: String, enum: ["low", "medium", "high"], required: true },
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // Reference to User model
  tags: [{ type: String }], // Array of tags
});

module.exports = mongoose.model("Todo", todoSchema);
