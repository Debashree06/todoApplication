const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true }, // Unique username
  name: { type: String, required: true }, // Full name
  email: { type: String, required: true, unique: true }, // Unique email
});

module.exports = mongoose.model("User", userSchema);
