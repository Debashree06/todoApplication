const express = require("express");
const Todo = require("../models/Todo");
const User = require("../models/User");

const router = express.Router();

// ✅ Get all Todos with filtering, sorting, and pagination
router.get("/", async (req, res) => {
  try {
    let { page = 1, limit = 5, priority, tag, user, sort } = req.query;
    page = parseInt(page);
    limit = parseInt(limit);

    let filter = {};
    if (priority) filter.priority = priority;
    if (tag) filter.tags = { $in: [tag] };
    if (user) filter.assignedTo = user;

    let sortOptions = {};
    if (sort === "priority") sortOptions.priority = 1; // Sort by priority (ascending)
    if (sort === "createdAt") sortOptions.createdAt = -1; // Sort by newest first

    const todos = await Todo.find(filter)
      .sort(sortOptions)
      .skip((page - 1) * limit)
      .limit(limit)
      .populate("assignedTo", "name email"); // Populate assigned user details

    const total = await Todo.countDocuments(filter);

    res.status(200).json({ total, page, limit, todos });
  } catch (error) {
    res
      .status(500)
      .json({ error: "Error fetching todos", details: error.message });
  }
});

// ✅ Get a single Todo by ID
router.get("/", async (req, res) => {
  try {
    let { page = 1, limit = 5, priority, tag, user, sort, search } = req.query;
    page = parseInt(page);
    limit = parseInt(limit);

    let filter = {};
    if (priority) filter.priority = priority;
    if (tag) filter.tags = { $in: [tag] };
    if (user) filter.assignedTo = user;

    // If search query exists, match it with title or description
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: "i" } },
        { description: { $regex: search, $options: "i" } },
      ];
    }

    let sortOptions = {};
    if (sort === "priority") sortOptions.priority = 1;
    if (sort === "createdAt") sortOptions.createdAt = -1;

    const todos = await Todo.find(filter)
      .sort(sortOptions)
      .skip((page - 1) * limit)
      .limit(limit)
      .populate("assignedTo", "name email");

    const total = await Todo.countDocuments(filter);

    res.status(200).json({ total, page, limit, todos });
  } catch (error) {
    res
      .status(500)
      .json({ error: "Error fetching todos", details: error.message });
  }
});

// ✅ Create a new Todo
router.post("/", async (req, res) => {
  try {
    const { title, description, priority, tags, assignedTo, mentions } =
      req.body;

    let mentionUsers = [];

    // Extract mentioned users if provided
    if (mentions && mentions.length > 0) {
      mentionUsers = await User.find({ username: { $in: mentions } }).select(
        "_id"
      );
      if (mentionUsers.length !== mentions.length) {
        return res
          .status(400)
          .json({ error: "Some mentioned users not found" });
      }
    }

    const newTodo = new Todo({
      title,
      description,
      priority,
      tags,
      assignedTo,
      mentions: mentionUsers.map((user) => user._id), // Store user IDs
    });

    await newTodo.save();
    res.status(201).json(newTodo);
  } catch (error) {
    res
      .status(500)
      .json({ error: "Error creating todo", details: error.message });
  }
});

// ✅ Update an existing Todo
router.put("/:id", async (req, res) => {
  try {
    const { mentions } = req.body;
    let mentionUsers = [];

    // Validate mentioned users
    if (mentions && mentions.length > 0) {
      mentionUsers = await User.find({ username: { $in: mentions } }).select(
        "_id"
      );
      if (mentionUsers.length !== mentions.length) {
        return res
          .status(400)
          .json({ error: "Some mentioned users not found" });
      }
    }

    const updatedTodo = await Todo.findByIdAndUpdate(
      req.params.id,
      { ...req.body, mentions: mentionUsers.map((user) => user._id) },
      { new: true }
    );

    if (!updatedTodo) return res.status(404).json({ error: "Todo not found" });

    res.status(200).json(updatedTodo);
  } catch (error) {
    res
      .status(500)
      .json({ error: "Error updating todo", details: error.message });
  }
});

// ✅ Delete a Todo
router.delete("/:id", async (req, res) => {
  try {
    const deletedTodo = await Todo.findByIdAndDelete(req.params.id);
    if (!deletedTodo) return res.status(404).json({ error: "Todo not found" });

    res.status(200).json({ message: "Todo deleted successfully" });
  } catch (error) {
    res
      .status(500)
      .json({ error: "Error deleting todo", details: error.message });
  }
});

module.exports = router;
