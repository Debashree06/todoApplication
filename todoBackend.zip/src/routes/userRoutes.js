const express = require("express");
const User = require("../models/User");
const router = express.Router();

// Get all users
router.get("/", async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Seed some users
router.post("/seed", async (req, res) => {
  try {
    const users = [
      { username: "bobsmith", email: "bob@example.com" },
      { username: "alicejones", email: "alice@example.com" },
      { username: "charlietom", email: "charlie@example.com" },
      { username: "davidlee", email: "david@example.com" },
      { username: "emilyclark", email: "emily@example.com" },
    ];
    await User.insertMany(users);
    res.json({ message: "Users added successfully!" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
