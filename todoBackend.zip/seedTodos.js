const mongoose = require("mongoose");
const Todo = require("./src/models/Todo");

// Example user ID - replace with real one from your database
const userId = new mongoose.Types.ObjectId();

const seedTodos = [
  {
    _id: new mongoose.Types.ObjectId(),
    title: "Integrate Payment Gateway",
    description: "Implement Stripe for online payments",
    priority: "high",
    assignedTo: userId,
    tags: ["payment", "stripe"], // Add tags here
  },
  {
    _id: new mongoose.Types.ObjectId(),
    title: "Fix Authentication Bugs",
    description: "Resolve login and session-related issues",
    priority: "medium",
    assignedTo: userId,
    tags: ["auth", "bugfix"], // Add tags here
  },
];

const seedDB = async () => {
  await Todo.deleteMany({}); // Clear existing todos
  await Todo.insertMany(seedTodos);
  console.log("Database seeded!");
  mongoose.connection.close();
};

mongoose
  .connect("mongodb://127.0.0.1:27017/todo-app", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("MongoDB connected");
    return seedDB();
  })
  .catch((err) => console.error(err));
