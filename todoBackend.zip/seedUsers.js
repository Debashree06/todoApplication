const mongoose = require("mongoose");
const User = require("./src/models/User");

// ✅ Use the correct MongoDB URL
const MONGO_URI = "mongodb://127.0.0.1:27017/todo-app"; // Ensure MongoDB is running!

// Connect to MongoDB
mongoose
  .connect(MONGO_URI)
  .then(() => console.log("✅ MongoDB Connected..."))
  .catch((err) => {
    console.error("❌ MongoDB Connection Error:", err);
    process.exit(1); // Exit if connection fails
  });
const users = [
  { username: "alicej", name: "Alice Johnson", email: "alice@example.com" },
  { username: "bobsmith", name: "Bob Smith", email: "bob@example.com" },
  { username: "charlieb", name: "Charlie Brown", email: "charlie@example.com" },
  { username: "davidlee", name: "David Lee", email: "david@example.com" },
  { username: "evagreen", name: "Eva Green", email: "eva@example.com" },
];

// Insert Users into the Database
async function seedUsers() {
  try {
    await mongoose.connect(MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log("🔥 Connected to MongoDB...");

    await User.deleteMany(); // Clear existing users
    console.log("🗑️ Cleared existing users...");

    const insertedUsers = await User.insertMany(users);
    console.log("✅ Users inserted:", insertedUsers);

    mongoose.connection.close();
    console.log("🔌 Database connection closed.");
  } catch (error) {
    console.error("❌ Error inserting users:", error);
    mongoose.connection.close();
  }
}
// Run the script
seedUsers();
